---
name: voice-rules
description: >
  Make a draft read like a person wrote it. Use when the user asks to edit,
  tighten, humanize, or "de-AI" a piece of writing, asks why a draft sounds
  like AI, or asks for a draft in their own voice. Runs the two-pass method
  from the Claude Writing guide at stevesaiguide.com: a mechanical word swap
  first, then a structural pass.
version: 1.0.0
---

# Voice Rules

Edit the user's writing so it stops sounding machine-written. Work in two
passes and keep them separate. Cut before you add.

If the user's instructions, project, or `CLAUDE.md` already hold a voice
profile or writing rules, those win over anything here.

## Pass 1: the swap pass (mechanical, change nothing else)

Replace these and touch nothing else. No restructuring, no rewriting.

**Banned words.** delve, leverage, utilize, facilitate, robust, seamless,
paramount, multifaceted, holistic, ever-evolving, pivotal, crucial,
meticulous, harness, unlock, elevate, foster, embark, underscore, arguably,
notably, interestingly, ultimately, furthermore, moreover, additionally.

**Banned phrases.** "in today's fast-paced world", "it's important to note",
"it's worth mentioning", "that said", "at its core", "when it comes to",
"in the realm of", "navigate the landscape", "paradigm shift",
"game-changer", "a tapestry of", "a testament to", "by doing X you can Y",
"whether you're A or B", "dive deep", "uncover insights", "unleash the power
of", "at the end of the day", "it goes without saying", "in conclusion".

**Swaps.**

| Instead of | Write |
|---|---|
| delve | examine, dig into, look at |
| leverage (verb), utilize, harness | use |
| facilitate | run, lead, help, set up |
| unlock | access, open, get to |
| elevate | raise, improve |
| foster | build, grow |
| paramount | most important |
| robust | strong, holds up |
| seamless | smooth |
| multifaceted | name the facets |
| holistic | whole-system, end-to-end |
| pivotal, crucial | key, must, required |
| furthermore, additionally | and, also |
| moreover, arguably, notably, interestingly, ultimately | cut |
| it's important to note that | cut it and say the thing |
| that said | but, still |
| when it comes to | for, on, in |
| by doing X, you can Y | X gets you Y |
| in conclusion | cut it and let the ending land |

**Soft ban, once per 1,000 words at most.** however, therefore, thus, hence,
indeed, in essence, in summary, in short. Also "significant", "substantial",
and "notable" whenever no number is attached.

Do not trade one machine voice for another. Never add "honestly", "look",
"here's the thing", or "hot take" to sound casual.

## Pass 2: the structural pass

Check the draft against these, in order.

1. **Specificity.** A number, name, date, or place in every paragraph. If a
   benefit has no number on it, it is not a claim yet. Ask the user for the
   real figure; never invent one.
2. **Rhythm.** Never three sentences of the same length in a row. Mix four
   words with thirty.
3. **Claims.** Each paragraph carries at least one statement someone could
   argue with. Remove stacked hedges and both-sides framing where the user
   asked for a position.
4. **Connectors.** Use a period where a transition word was doing the work.
5. **Structure.** No "Key Takeaways" or summary block at the end. No heading
   every 80 words. No three-item list by reflex. Bullets only where the
   content is a list. Bold is rare.
6. **Punctuation.** At most one em-dash per 125 words. Sentence case in
   headings unless the user's own style says otherwise.

Tells to look for while you do this: "It's not just X, it's Y"; a rhetorical
question answered on the spot; the same sentence opening three times in a
row; a motivational close; vulnerability with no names, dates, or amounts.

## Writing in the user's voice

If asked to write as the user and no voice profile exists, say so and offer
to build one. With a mail connector available and the user's go-ahead, read
their last 30 sent emails and write a profile: how they greet, how they sign
off, sentence length, phrases they reach for, words they never use. Show it
to them before it is saved; they should delete any habit they do not want
reinforced.

## What to hand back

- The edited draft.
- Three lines at most on what changed.
- What you would cut next. Never tell the user a draft is done.

Do not add facts, quotes, statistics, or anecdotes the user did not supply.
