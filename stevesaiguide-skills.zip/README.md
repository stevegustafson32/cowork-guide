# stevesaiguide-skills

Two skills that go with the guides at [stevesaiguide.com](https://stevesaiguide.com). Skills only: no connectors, no commands, nothing that runs on your computer.

| Skill | What it does | Guide |
|---|---|---|
| `voice-rules` | Edits a draft so it reads like a person wrote it. A mechanical word-swap pass, then a structural pass. | [Claude Writing](https://stevesaiguide.com/claude-writing.html) |
| `prompt-coach` | Reviews a prompt before you run it. Scores it on five parts and hands back a rewrite. | [The Prompting Guide](https://stevesaiguide.com/prompting.html) |

## Install

1. Download `stevesaiguide-skills.zip` from the guide page.
2. In Claude, open **Customize**, then **Plugins**, then **Add**, then **Upload plugin**.
3. Pick the zip and click **Upload**.

Claude then uses each skill when the request fits. You can also ask for one by name: "use voice-rules on this draft."

## Before you install any plugin

Read the files. Each skill is one short text file under `skills/`. The check to run on any plugin is in [Claude Plugins](https://stevesaiguide.com/claude-plugins.html#five-minute-check).

## Build the zip

```bash
zip -r stevesaiguide-skills.zip .claude-plugin skills README.md LICENSE
```

MIT License.
